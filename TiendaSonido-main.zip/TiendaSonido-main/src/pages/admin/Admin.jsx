import AdminLayout from '../../components/templates/AdminLayout'
import AdminPedidosContainer from '../../containers/AdminPedidosContainer'
import AdminProductosContainer from '../../containers/AdminProductosContainer'
import AdminUsuariosContainer from '../../containers/AdminUsuariosContainer'
import { useAuth } from '../../context/AuthContext'
import { NOMBRE_ROL } from '../../data/usuarios'

/**
 * Página de administración (Container de página).
 *
 * Responsabilidad: obtener el estado de autenticación y los permisos,
 * y suministrar los contenedores y datos correspondientes al template AdminLayout.
 */
export default function Admin() {
  const { usuario, tieneRol } = useAuth()
  const esAdmin = tieneRol('admin')
  const rolLabel = NOMBRE_ROL[usuario.rol]

  return (
    <AdminLayout
      rolLabel={rolLabel}
      esAdmin={esAdmin}
      tabPedidos={<AdminPedidosContainer />}
      tabProductos={<AdminProductosContainer puedeEditarCatalogo={esAdmin} />}
      tabUsuarios={<AdminUsuariosContainer />}
    />
  )
}
