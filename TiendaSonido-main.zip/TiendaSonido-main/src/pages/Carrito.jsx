import { useState } from 'react'
import { Button, Col, Container, Row } from 'react-bootstrap'
import { Link, useNavigate } from 'react-router-dom'
import ListaCarrito from '../components/organisms/ListaCarrito/ListaCarrito'
import ResumenPedido from '../components/organisms/ResumenPedido/ResumenPedido'
import { useAuth } from '../context/AuthContext'
import { useCarrito } from '../context/CarritoContext'
import {
  guardarPedidos,
  guardarProductos,
  obtenerPedidos,
  obtenerProductos,
} from '../services/almacenamiento'
import { descontarStock } from '../utils/carrito'
import { crearPedido } from '../utils/pedidos'

const DIRECCION_TIENDA = 'Tienda Sonido Vivo, Viña del Mar'

export default function Carrito() {
  const { carrito, cambiarCantidad, quitar, vaciar, total } = useCarrito()
  const { usuario } = useAuth()
  const navigate = useNavigate()
  const [tipoEntrega, setTipoEntrega] = useState('despacho')
  const [direccion, setDireccion] = useState(
    usuario ? `${usuario.direccion}, ${usuario.comuna}` : '',
  )
  const [error, setError] = useState('')

  function confirmarPedido() {
    if (!usuario) {
      navigate('/login', { state: { desde: '/carrito' } })
      return
    }
    if (tipoEntrega === 'despacho' && !direccion.trim()) {
      setError('Ingresa la dirección de despacho.')
      return
    }

    // El stock se descuenta al confirmar (evita vender lo mismo dos veces)
    const productosActualizados = descontarStock(obtenerProductos(), carrito)
    if (!productosActualizados) {
      setError('Uno o más productos ya no tienen stock suficiente. Revisa tu carrito.')
      return
    }

    const pedidos = obtenerPedidos()
    const pedido = crearPedido({
      carrito,
      usuario,
      pedidosExistentes: pedidos,
      entrega: {
        tipo: tipoEntrega,
        direccion: tipoEntrega === 'despacho' ? direccion.trim() : DIRECCION_TIENDA,
      },
    })
    guardarProductos(productosActualizados)
    guardarPedidos([...pedidos, pedido])
    vaciar()
    navigate('/mis-pedidos', { state: { nuevo: pedido.numero } })
  }

  if (carrito.length === 0) {
    return (
      <Container className="py-5 text-center">
        <h1 className="h3">Mi carrito de compras</h1>
        <p className="text-muted">El carrito está vacío.</p>
        <Button as={Link} to="/productos" variant="warning">
          Ver productos
        </Button>
      </Container>
    )
  }

  return (
    <Container className="py-4">
      <h1 className="h3 mb-4">Mi carrito de compras</h1>
      <Row className="g-4">
        <Col lg={8}>
          <ListaCarrito
            items={carrito}
            onCambiarCantidad={cambiarCantidad}
            onQuitar={quitar}
            onVaciar={vaciar}
          />
        </Col>

        <Col lg={4}>
          <ResumenPedido
            tipoEntrega={tipoEntrega}
            onTipoEntregaChange={setTipoEntrega}
            direccion={direccion}
            onDireccionChange={setDireccion}
            total={total}
            error={error}
            esUsuarioAutenticado={!!usuario}
            onConfirmar={confirmarPedido}
          />
        </Col>
      </Row>
    </Container>
  )
}
