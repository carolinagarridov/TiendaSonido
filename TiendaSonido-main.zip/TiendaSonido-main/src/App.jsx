import { Route, Routes } from 'react-router-dom'
import RutaProtegida from './guards/RutaProtegida/RutaProtegida'
import TiendaLayout from './components/templates/TiendaLayout'
import Admin from './pages/admin/Admin'
import Carrito from './pages/Carrito'
import Inicio from './pages/Inicio'
import Login from './pages/Login'
import MisPedidos from './pages/MisPedidos'
import NoEncontrado from './pages/NoEncontrado'
import Productos from './pages/Productos'
import Registro from './pages/Registro'

export default function App() {
  return (
    <TiendaLayout>
      <Routes>
        <Route path="/" element={<Inicio />} />
        <Route path="/productos" element={<Productos />} />
        <Route path="/login" element={<Login />} />
        <Route path="/registro" element={<Registro />} />
        <Route path="/carrito" element={<Carrito />} />
        <Route
          path="/mis-pedidos"
          element={
            <RutaProtegida>
              <MisPedidos />
            </RutaProtegida>
          }
        />
        <Route
          path="/admin"
          element={
            <RutaProtegida roles={['admin', 'vendedor']}>
              <Admin />
            </RutaProtegida>
          }
        />
        <Route path="*" element={<NoEncontrado />} />
      </Routes>
    </TiendaLayout>
  )
}
