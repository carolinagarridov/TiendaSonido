import { useMemo, useState } from 'react'
import { obtenerProductos } from '../services/almacenamiento'

/**
 * Hook para cargar y filtrar productos por búsqueda de texto y categoría.
 */
export function useFiltroProductos() {
  const [productos] = useState(() => obtenerProductos())
  const [categoria, setCategoria] = useState('Todas')
  const [busqueda, setBusqueda] = useState('')

  const filtrados = useMemo(() => {
    const texto = busqueda.trim().toLowerCase()
    return productos.filter(
      (p) =>
        (categoria === 'Todas' || p.categoria === categoria) &&
        (!texto ||
          `${p.nombre} ${p.marca} ${p.modelo}`.toLowerCase().includes(texto)),
    )
  }, [productos, categoria, busqueda])

  return {
    productos,
    filtrados,
    categoria,
    setCategoria,
    busqueda,
    setBusqueda,
  }
}

