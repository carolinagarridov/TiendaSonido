import { Container, Tab, Tabs } from 'react-bootstrap'
import AdminPedidosContainer from '../../containers/AdminPedidosContainer'
import AdminProductosContainer from '../../containers/AdminProductosContainer'
import AdminUsuariosContainer from '../../containers/AdminUsuariosContainer'

/**
 * Template del panel de administración.
 *
 * Define la estructura de pestañas del panel administrativo.
 *
 * @param {object} props
 * @param {string} props.rolLabel - Nombre legible del rol en sesión.
 * @param {boolean} props.esAdmin - Booleano para determinar si se habilita la pestaña de usuarios.
 * @param {React.ReactNode} [props.tabPedidos] - Slot para la vista de pedidos.
 * @param {React.ReactNode} [props.tabProductos] - Slot para la vista de inventario.
 * @param {React.ReactNode} [props.tabUsuarios] - Slot para la vista de gestión de usuarios.
 */
export default function AdminLayout({
  rolLabel,
  esAdmin,
  tabPedidos = <AdminPedidosContainer />,
  tabProductos = <AdminProductosContainer puedeEditarCatalogo={esAdmin} />,
  tabUsuarios = <AdminUsuariosContainer />,
}) {
  return (
    <Container className="py-4">
      <div className="d-flex flex-wrap justify-content-between align-items-center mb-3">
        <h1 className="h3 mb-0">Panel de administración</h1>
        <span className="text-muted small">Sesión: {rolLabel}</span>
      </div>
      <Tabs defaultActiveKey="pedidos" className="mb-4" mountOnEnter>
        <Tab eventKey="pedidos" title="Pedidos">
          {tabPedidos}
        </Tab>
        <Tab eventKey="productos" title="Productos">
          {tabProductos}
        </Tab>
        {esAdmin && (
          <Tab eventKey="usuarios" title="Usuarios">
            {tabUsuarios}
          </Tab>
        )}
      </Tabs>
    </Container>
  )
}
