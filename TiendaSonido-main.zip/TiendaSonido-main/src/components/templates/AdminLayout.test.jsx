import { render, screen } from '@testing-library/react'
import { describe, expect, it } from 'vitest'
import AdminLayout from './AdminLayout'

describe('<AdminLayout /> Template', () => {
  it('muestra título, rol de sesión y pestañas para admin', () => {
    render(
      <AdminLayout
        rolLabel="Administrador"
        esAdmin={true}
        tabPedidos={<div>Contenido Pedidos</div>}
        tabProductos={<div>Contenido Productos</div>}
        tabUsuarios={<div>Contenido Usuarios</div>}
      />,
    )

    expect(screen.getByRole('heading', { name: /panel de administración/i })).toBeInTheDocument()
    expect(screen.getByText(/sesión: administrador/i)).toBeInTheDocument()
    expect(screen.getByRole('tab', { name: /pedidos/i })).toBeInTheDocument()
    expect(screen.getByRole('tab', { name: /productos/i })).toBeInTheDocument()
    expect(screen.getByRole('tab', { name: /usuarios/i })).toBeInTheDocument()
  })

  it('no muestra la pestaña de usuarios si esAdmin es false', () => {
    render(
      <AdminLayout
        rolLabel="Vendedor"
        esAdmin={false}
        tabPedidos={<div>Contenido Pedidos</div>}
        tabProductos={<div>Contenido Productos</div>}
        tabUsuarios={<div>Contenido Usuarios</div>}
      />,
    )

    expect(screen.getByRole('tab', { name: /pedidos/i })).toBeInTheDocument()
    expect(screen.getByRole('tab', { name: /productos/i })).toBeInTheDocument()
    expect(screen.queryByRole('tab', { name: /usuarios/i })).not.toBeInTheDocument()
  })
})

